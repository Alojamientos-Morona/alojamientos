<?php
require_once 'models/permiso.php';

function hasPermission($permiso) {
    if (!isset($_SESSION['permisos'])) return false;
    return in_array($permiso, $_SESSION['permisos']);
}

function loadUserPermissions($userId) {
    $permisos = Permiso::getPermisosByUserId($userId);
    return array_column($permisos, 'nombre');
}
?>
