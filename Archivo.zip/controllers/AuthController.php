<?php

require_once 'models/usuario.php';

class AuthController {
    private $usuarioModel;

    public function __construct($conn) {
        $this->usuarioModel = new Usuario($conn);
    }

    public function login() {
        require 'config/database.php';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $password = $_POST['password'];

            $usuario = $this->usuarioModel->obtenerPorEmail($email);
 if ($usuario && password_verify($password, $usuario['password'])) {
                $_SESSION['user_id'] = $usuario['id'];
                $_SESSION['usuario_nombre'] = $usuario['nombre'] ?? $usuario['email'];
                require_once 'helpers/permisos.php';
                $_SESSION['permisos'] = loadUserPermissions($userId);
                header("Location: index.php?url=usuarios");
                exit;
            } else {
                $_SESSION['error'] = 'Credenciales incorrectas';
                header("Location: index.php?url=login");
                exit;

            }
        } else {
            require 'views/auth/login.php';
        }
    }

    public function loginSubmit() {
        // Este método ya no es necesario porque la lógica está en login()
        // Puedes eliminar la ruta 'loginSubmit' del routes.php si quieres simplificar
    }

    public function register($nombre, $email, $password) {
        if ($this->usuarioModel->obtenerPorEmail($email)) {
            return false;
        }

        $usuario_id = $this->usuarioModel->crear($nombre, $email, $password);
        return $usuario_id ? true : false;
    }

    public function logout() {
        session_destroy();
        header("Location: index.php?url=login");
        exit;
    }
}
?>
