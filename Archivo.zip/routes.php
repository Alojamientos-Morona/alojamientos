<?php

require_once 'helpers/permisos.php';

function isAdmin() {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    require_once 'models/rol.php';
    $roles = Rol::getRolesByUserId($_SESSION['user_id']);
    foreach ($roles as $rol) {
        if ($rol['nombre'] === 'Admin') {
            return true;
        }
    }
    return false;
}

/*function hasPermission($permiso) {
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    require_once 'models/rol.php';
    $permisos = Rol::getPermissionsByUserId($_SESSION['user_id']);
    return in_array($permiso, $permisos);
}
*/
function route($url) {
    switch ($url) {
        case 'login':
            require_once 'controllers/AuthController.php';
            require 'config/database.php';
            $controller = new AuthController($conn);
            $controller->login();
            break;

        case 'loginSubmit':
            require_once 'controllers/AuthController.php';
            require 'config/database.php';
            $controller = new AuthController($conn);
            $controller->loginSubmit();
            break;

        case 'logout':
            require_once 'controllers/AuthController.php';
            require 'config/database.php';
            $controller = new AuthController($conn);
            $controller->logout();
            break;

        case 'usuarios':
//if (!hasPermission('crear_roles')) { echo 'Acceso denegado'; exit; }

            if (!hasPermission('view_users')) {
                echo "Acceso denegado";
                exit;
            }
            require_once 'controllers/usuariocontroller.php';
            require 'config/database.php';
            $controller = new UsuarioController();
            $controller->index();
            break;

        case 'assignRolesForm':
            if (!hasPermission('assign_roles')) {
                echo "Acceso denegado";
                exit;
            }
            require_once 'controllers/usuariocontroller.php';
            require 'config/database.php';
            $controller = new UsuarioController();
            $controller->assignRolesForm();
            break;

        case 'assignRolesSubmit':
            if (!hasPermission('assign_roles')) {
                echo "Acceso denegado";
                exit;
            }
            require_once 'controllers/usuariocontroller.php';
            require 'config/database.php';
            $controller = new UsuarioController();
            $controller->assignRolesSubmit();
            break;
        case 'dashboard':
            require 'views/dashboard/index.php';
            break;

        case 'updateUserAndRole':
            require_once 'controllers/usuariocontroller.php';
            require 'config/database.php';
            $controller = new UsuarioController();
            $controller->updateUserAndRole();
            break;

        case 'createUser':
            require_once 'controllers/usuariocontroller.php';
            require 'config/database.php';
            $controller = new UsuarioController();
            $controller->createUser();
            break;
        case 'deleteUser':
            require_once 'controllers/usuariocontroller.php';
            require 'config/database.php';
            $controller = new UsuarioController();
            $controller->deleteUser();
            break;
        case 'roles':
            require_once 'controllers/rolcontroller.php';
            require 'config/database.php';
            $controller = new RolController();
            $controller->index();
            break;

        case 'createRole':
            require_once 'controllers/rolcontroller.php';
            require 'config/database.php';
            $controller = new RolController();
            $controller->createRole();
            break;

        case 'updateRole':
            require_once 'controllers/rolcontroller.php';
            require 'config/database.php';
            $controller = new RolController();
            $controller->updateRole();
            break;

        case 'deleteRole':
            require_once 'controllers/rolcontroller.php';
            require 'config/database.php';
            $controller = new RolController();
            $controller->deleteRole();
            break;
        case 'rolesPermisos':
            require_once 'controllers/rolcontroller.php';
            require 'config/database.php';
            $controller = new RolController();
            $controller->rolesPermisos();
            break;

        case 'getPermisosPorRol':
            require_once 'controllers/rolcontroller.php';
            require 'config/database.php';
            $controller = new RolController();
            $controller->getPermisosPorRol();
            break;

        case 'savePermisosPorRol':
            require_once 'controllers/rolcontroller.php';
            require 'config/database.php';
            $controller = new RolController();
            $controller->savePermisosPorRol();
            break;


        default:
            echo "404 - Página no encontrada";
            break;
    }
}
?>