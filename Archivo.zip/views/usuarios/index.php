
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Usuarios</title>
    <?php require 'views/layouts/start.php'; ?>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .pagination { justify-content: center; }
    </style>
</head>
<body class="bg-light">
<?php include 'views/partials/navbar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Listado de Usuarios</h2>
    <!-- Botón Crear Usuario -->
    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#createUserModal">+ Crear Usuario</button>


    <!-- Filtro -->
    <div class="mb-3">
        <input type="text" id="searchInput" class="form-control" placeholder="Buscar por Email o Rol...">
    </div>

    <!-- Botón Exportar CSV -->
    <div class="mb-3">
        <a href="index.php?url=exportUsersCSV" class="btn btn-secondary">Exportar CSV</a>
    </div>

    <!-- Tabla Usuarios -->
    <table class="table table-bordered table-striped" id="usuariosTable">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Roles</th>
                <th>Acciones</th>

            </tr>
        </thead>
        <tbody>
        <?php foreach ($usuarios as $usuario): ?>
            <tr data-user-id="<?= $usuario['id'] ?>" data-user-email="<?= htmlspecialchars($usuario['email']) ?>">
                <td><?= htmlspecialchars($usuario['id']) ?></td>
                <td><?= htmlspecialchars($usuario['email']) ?></td>
                <td>
                    <?php foreach ($usuario['roles'] as $rol): ?>
                        <?= htmlspecialchars($rol['nombre']) ?><br>
                    <?php endforeach; ?>
                </td>
                <td>
                    <?php if (hasPermission('assign_roles')): ?>
                        <button class="btn btn-sm btn-warning edit-user-btn" data-bs-toggle="modal" data-bs-target="#editUserModal"
                                data-user-id="<?= $usuario['id'] ?>"
                                data-user-email="<?= htmlspecialchars($usuario['email']) ?>"
                                data-user-role="<?= isset($usuario['roles'][0]['id']) ? $usuario['roles'][0]['id'] : '' ?>">
                            Editar / Asignar Rol
                        </button>
                        <button class="btn btn-sm btn-danger delete-user-btn" data-user-id="<?= $usuario['id'] ?>" data-user-email="<?= htmlspecialchars($usuario['email']) ?>">
                            Eliminar
                        </button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Toast -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div id="toastMsg" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                Acción realizada correctamente.
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Cerrar"></button>
        </div>
    </div>
</div>

<!-- Modales -->
<!-- Modal Editar Usuario -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Editar Usuario / Asignar Rol</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <input type="hidden" name="user_id" id="user_id">

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="email" required>
                    </div>

                    <div class="mb-3">
                        <label for="role_id" class="form-label">Rol</label>
                        <select name="role_id" id="role_id" class="form-select">
                            <?php foreach ($roles as $rol): ?>
                                <option value="<?= $rol['id'] ?>"><?= htmlspecialchars($rol['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Crear Usuario -->
<div class="modal fade" id="createUserModal" tabindex="-1" aria-labelledby="createUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createUserModalLabel">Crear Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <form id="createUserForm">

                    <div class="mb-3">
                        <label for="new_email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="new_email" required>
                    </div>

                    <div class="mb-3">
                        <label for="new_password" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" name="password" id="new_password" required>
                    </div>

                    <div class="mb-3">
                        <label for="new_role_id" class="form-label">Rol</label>
                        <select name="role_id" id="new_role_id" class="form-select">
                            <?php foreach ($roles as $rol): ?>
                                <option value="<?= $rol['id'] ?>"><?= htmlspecialchars($rol['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-success">Crear Usuario</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Eliminación -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="confirmDeleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmDeleteModalLabel">Confirmar Eliminación</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                ¿Está seguro que desea eliminar al usuario <strong id="deleteUserEmail"></strong>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Eliminar</button>
            </div>
        </div>
    </div>
</div>
    <!-- Pagination -->
    <nav>
        <ul class="pagination"></ul>
    </nav>
</div>



<script>
    $(document).ready(function() {
        $('.edit-user-btn').on('click', function() {
            var userId = $(this).data('user-id');
            var userEmail = $(this).data('user-email');
            var userRole = $(this).data('user-role');

            $('#user_id').val(userId);
            $('#email').val(userEmail);
            $('#role_id').val(userRole);
        });

        $('#editUserForm').submit(function(e) {
            e.preventDefault();

            $.ajax({
                url: 'index.php?url=updateUserAndRole',
                method: 'POST',
                data: $(this).serialize(),
                success: function(response) {
                    showToast('Usuario actualizado correctamente');
                    setTimeout(() => location.reload(), 1000);
                },
                error: function() {
                    showToast('Error al actualizar el usuario');
                }
            });
        });

        $('#createUserForm').submit(function(e) {
            e.preventDefault();

            $.ajax({
                url: 'index.php?url=createUser',
                method: 'POST',
                data: $(this).serialize(),
                success: function(response) {
                    if (response.includes('duplicate')) {
                        showToast('Error: Email ya registrado');
                    } else {
                        showToast('Usuario creado correctamente');
                        setTimeout(() => location.reload(), 1000);
                    }
                },
                error: function() {
                    showToast('Error al crear el usuario');
                }
            });
        });

        var deleteUserId = null;
        $('.delete-user-btn').on('click', function() {
            deleteUserId = $(this).data('user-id');
            var userEmail = $(this).data('user-email');
            $('#deleteUserEmail').text(userEmail);
            $('#confirmDeleteModal').modal('show');
        });

        $('#confirmDeleteBtn').on('click', function() {
            $.ajax({
                url: 'index.php?url=deleteUser',
                method: 'POST',
                data: { user_id: deleteUserId },
                success: function(response) {
                    showToast('Usuario eliminado correctamente');
                    $('#confirmDeleteModal').modal('hide');
                    setTimeout(() => location.reload(), 1000);
                },
                error: function() {
                    showToast('Error al eliminar el usuario');
                }
            });
        });

        function showToast(message) {
            $('#toastMsg .toast-body').text(message);
            var toast = new bootstrap.Toast(document.getElementById('toastMsg'));
            toast.show();
        }

    // Filtro
    $("#searchInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#usuariosTable tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    // Pagination simple
    var rowsPerPage = 5;
    var rows = $('#usuariosTable tbody tr');
    var rowsCount = rows.length;
    var pageCount = Math.ceil(rowsCount / rowsPerPage);
    var numbers = $('.pagination');

    for (var i = 0; i < pageCount; i++) {
        numbers.append('<li class="page-item"><a href="#" class="page-link">' + (i+1) + '</a></li>');
    }

    $('#usuariosTable tbody tr').hide();
    $('#usuariosTable tbody tr').slice(0, rowsPerPage).show();
    $('.pagination li:first').addClass('active');

    $('.pagination li').on('click', function(){
        var index = $(this).index();
        $('.pagination li').removeClass('active');
        $(this).addClass('active');
        var start = index * rowsPerPage;
        var end = start + rowsPerPage;
        $('#usuariosTable tbody tr').hide().slice(start, end).show();
    });
});
</script>
<?php require 'views/layouts/end.php'; ?>

</body>
</html>
