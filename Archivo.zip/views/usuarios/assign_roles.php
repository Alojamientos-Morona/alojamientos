<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Asignar Rol</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="mb-4">Asignar Rol a <?= htmlspecialchars($usuario['email']) ?></h2>

    <form method="POST" action="index.php?url=assignRolesSubmit">
        <input type="hidden" name="user_id" value="<?= $usuario['id'] ?>">

        <div class="mb-3">
            <label for="role_id" class="form-label">Rol</label>
            <select name="role_id" id="role_id" class="form-select" required>
                <?php foreach ($roles as $rol): ?>
                    <option value="<?= $rol['id'] ?>"><?= htmlspecialchars($rol['nombre']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Asignar Rol</button>
        <a href="index.php?url=usuarios" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

</body>
</html>