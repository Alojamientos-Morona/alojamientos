
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Roles</title>
    <?php require 'views/layouts/start.php'; ?>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
<?php include 'views/partials/navbar.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Listado de Roles</h2>

    <!-- Botón Crear Rol -->
    <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#createRoleModal">+ Crear Rol</button>

    <!-- Tabla Roles -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($roles as $rol): ?>
                <tr>
                    <td><?= htmlspecialchars($rol['id']) ?></td>
                    <td><?= htmlspecialchars($rol['nombre']) ?></td>
                    <td><?= htmlspecialchars($rol['descripcion']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Toast -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
  <div id="toastMsg" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">
        Acción realizada correctamente.
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Cerrar"></button>
    </div>
  </div>
</div>

<!-- Modal Crear Rol -->
<div class="modal fade" id="createRoleModal" tabindex="-1" aria-labelledby="createRoleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createRoleModalLabel">Crear Rol</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <form id="createRoleForm">

          <div class="mb-3">
            <label for="role_name" class="form-label">Nombre del Rol</label>
            <input type="text" class="form-control" name="nombre" id="role_name" required>
          </div>

          <div class="mb-3">
            <label for="role_description" class="form-label">Descripción</label>
            <textarea class="form-control" name="descripcion" id="role_description" required></textarea>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-success">Crear Rol</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function() {
    $('#createRoleForm').submit(function(e) {
        e.preventDefault();

        $.ajax({
            url: 'index.php?url=createRole',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.includes('duplicate')) {
                    showToast('Error: El rol ya existe');
                } else {
                    showToast('Rol creado correctamente');
                    setTimeout(() => location.reload(), 1000);
                }
            },
            error: function() {
                showToast('Error al crear el rol');
            }
        });
    });

    function showToast(message) {
        $('#toastMsg .toast-body').text(message);
        var toast = new bootstrap.Toast(document.getElementById('toastMsg'));
        toast.show();
    }
});
</script>
<?php require 'views/layouts/end.php'; ?>

</body>
</html>
