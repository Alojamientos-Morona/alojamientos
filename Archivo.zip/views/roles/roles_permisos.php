
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Asignar Permisos a Roles</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">

<div class="container mt-5">
  <h2 class="mb-4">Asignar Permisos a Roles</h2>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($roles as $rol): ?>
      <tr>
        <td><?= htmlspecialchars($rol['id']) ?></td>
        <td><?= htmlspecialchars($rol['nombre']) ?></td>
        <td>
          <button class="btn btn-primary btn-sm assign-permissions-btn"
            data-role-id="<?= $rol['id'] ?>"
            data-role-nombre="<?= htmlspecialchars($rol['nombre']) ?>"
            data-bs-toggle="modal" data-bs-target="#assignPermissionsModal">Asignar Permisos</button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- Modal Asignar Permisos -->
<div class="modal fade" id="assignPermissionsModal" tabindex="-1" aria-labelledby="assignPermissionsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Asignar Permisos a <span id="assign_role_name"></span></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <form id="assignPermissionsForm">
          <input type="hidden" name="role_id" id="assign_role_id">
          <div class="row">
            <?php foreach ($permisos as $permiso): ?>
            <div class="col-md-4 mb-2">
              <div class="form-check">
                <input class="form-check-input permiso-checkbox" type="checkbox"
                  name="permisos[]" value="<?= $permiso['id'] ?>" id="permiso<?= $permiso['id'] ?>">
                <label class="form-check-label" for="permiso<?= $permiso['id'] ?>">
                  <?= htmlspecialchars($permiso['nombre']) ?>
                </label>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button type="submit" class="btn btn-success">Guardar Permisos</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
$(function() {
  $('.assign-permissions-btn').click(function() {
    const roleId = $(this).data('role-id');
    const roleName = $(this).data('role-nombre');
    $('#assign_role_id').val(roleId);
    $('#assign_role_name').text(roleName);

    $('.permiso-checkbox').prop('checked', false);

    $.getJSON('index.php?url=getPermisosPorRol', { role_id: roleId }, function(permisosActuales) {
      permisosActuales.forEach(id => {
        $('#permiso' + id).prop('checked', true);
      });
    });
  });

  $('#assignPermissionsForm').submit(function(e) {
    e.preventDefault();
    $.post('index.php?url=savePermisosPorRol', $(this).serialize(), function(res) {
      alert('Permisos actualizados');
      $('#assignPermissionsModal').modal('hide');
    });
  });
});
</script>

</body>
</html>
